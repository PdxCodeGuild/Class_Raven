class Typing:
  def __init__(typing, data):
    typing.name = data['name']
    typing.immunities = data['zero']
    typing.resistances = data['half']
    typing.weaknesses = data['double']
